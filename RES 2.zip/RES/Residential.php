<?php
session_start();

if(isset($_SESSION['ID'])){

 $city=$_POST['city'];
 $PINcode=intval($_POST['pin']);
 $SCname=$_POST['society'];
 $FPno=intval($_POST['fno']);
 $PA=$_POST['padd'];
 $PC=$_POST['config'];
 $PS=$_POST['status'];
 $SType=$_POST['sale'];
 $Asf=intval($_POST['size']);
 $Rpsf=intval($_POST['rate']);
 $price=intval($_POST['price']);

 
 $pid=$_SESSION['last_id'] ;



 
 $conn = new mysqli('localhost','root','','RealEstate');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {

		



		$sql = ("update Property set City = ?, PINcode=?, SCName=?, FPno=?, PropertyAddress=?, PropertyConfiguration=?, PropertyStatus= ?, SaleType=?, AreaSqFt=?, RatePrSqFt=?, Price=? where PropertyID =?");
		
		$stmt = $conn->prepare($sql);

// Bind parameters
    // $stmt->bind_param("si", $newValue, $idToUpdate);
		$stmt->bind_param("sisissssiiii",$city, $PINcode, $SCname, $FPno, $PA,  $PC, $PS, $SType, $Asf, $Rpsf, $price, $pid);
		$execval = $stmt->execute();
		echo $execval;
		echo "Recorded!";
		$stmt->close();
		$conn->close();
	}
	
	
		header("Location: upload-image/");
        exit; 
	
	
}
 
?>