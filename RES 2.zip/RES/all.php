<!DOCTYPE html>
<html>
<head>
    <title>Filter and Retrieve Data</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link  rel="stylesheet" href="search.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
     <script>
      
      function show(id) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "http://localhost/view.php?t1="+id, true);
        xhr.send();
//xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

//xhr.send("t1=" + id);
        window.location.href="http://localhost/view.php?t1="+id;
    }
      </script>
</head>
<body>


 <header id="h1">
     <label for="logo">REAL ESTATE SOLUTION</label>
 </header>
          <header id="h2">
            <nav>
              <ul>
                
                <li><a href="http://localhost/home2.html">HOME</a></li>
                <li><a href="http://localhost/aboutus.html">ABOUT</a></li>
                <li><a href="http://localhost/buy.php">BUY</a></li>
                <li><a href="http://localhost/rent.php">RENT</a></li>
                <li><a href="http://localhost/login.html">SALE</a></li>
                <li><a href="http://localhost/home1.html">PROPERTY SERVICES</a></li>
                <li class="dropdown">
                  
                  <a href="" class="dropbtn">ACCOUNT</a>
                  <div class="dropdown-content">
                    <a href="http://localhost/Login.html">Login </a>
                    <a href="http://localhost/Signin.html">Sign in</a>
                  </div></li>
                  
                  <li class="dropdown">
                    <a href="" class="dropbtn">HELP</a>
                  <div class="dropdown-content">
                    <a href="http://localhost/Login.html">#phone </a>
                    <a href="http://localhost/Signin.html">#email</a>
                  </div></li>
              </ul>
            </nav>
          </header>
    <div class="login-container">
        <div class="filter">
     <form  method="Post">
        <div class="form" >
            <input class="search" type="text" name="city" placeholder="Search City...">
        </div>
     
        <div class="form" >
          <label for="category">Property Type : </label>
           <select name="category" id="category">
              <option value="all">All Categories</option>
              <option value="Residential" >Residential</option>
              <option value="Commercial">Commercial</option>
              </select></div>
            <!--  -->
            <div class="form" >
            <label for="cat">Sale Type : </label>
             <select name="caty" id="cat">
              <option value="Sell">Buy </option>
              <option value="Rent" >Rent</option>
              
            <!--  -->
           </select></div><br><br>
           <div class="form">
            <label for="budget">Budget : </label>
            <input type="Number" name="budget" id="budget">
           </div>
           <div class="form">
        <input type="submit" class="button"  value="filter" name="submit"></div>
    </form></div>
</div>

<div class="login-container11">
    
    <?php
    // Database connection
    $a=[];
    $conn = new mysqli("localhost", "root", "", "RealEstate");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    //echo"<table>";
    if (!isset($_POST['submit'])){
    $sql = "SELECT * FROM Property  ";
    $result = $conn->query($sql);        
    if ($result->num_rows > 0){
     //   echo "<table class='login-container1'>";
    while($row1 = $result->fetch_assoc()){
    $id=$row1["PropertyID"];
     //"<div id='i'>".$a[$i]=$id."</div>";
     $buttonID =  $id;
     
   // $pid[]=$id;
    
    $sql2="SELECT * FROM images WHERE PropertyID = $id  ORDER BY id DESC";
    $result2 = $conn->query($sql2);
    //while($row2 = $result2->fetch_assoc()){
        $row2 = $result2->fetch_assoc();
        $id1=$row2["images_url"];
        echo "<button id='$id' onclick='show(this.id)'>";
        
        echo "<div><table class='container'>";
       // echo "<tr class='login-container1'> ";
       echo $id;
        echo "<tr><td>"?> <div class="alb">
        <img id="img" src="upload-image/uploads/<?=$id1?>" style="width:100% ; height:100%">
         </div> <?php "</td></tr>";
        echo "<tr><td> <label> Name : </label>".$row1["RepresentativeName"]."</td></tr>";
        echo "<tr><td> <label> Email : </label>".$row1["Email"]."</td></tr>";
        echo "<tr><td><label> Representative type : </label>".$row1["RepresentativeType"]."</td></tr>";
        echo "<tr><td> <label> Location : </label>".$row1["PropertyAddress"]."</td></tr>";
       // echo "</tr>";
        echo "</table></div>";
        $i++;
        echo "</button>";
  //  }      
    }// echo "</table>";
} }
    
    // Handle form submission
     
    /*if (isset($_POST['search'])) {
        $search = $_POST['city'];
        $sql = "SELECT * FROM Property WHERE City ='$search' ";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "Name : " . $row["RepresentativeName"]. " - Email: " . $row["Email"]. " - Address: " . $row["PropertyAdddress"]. "<br>";
            }
        } else {
            echo "No results found";
        }
        }*/

    

    $pid=array();
    if (isset($_POST['submit'])) {
        $category = $_POST['category'];
        $cat=$_POST['cat'];
        $search = $_POST['city'];
        $budget=$_POST['budget'];
       
        //echo "<table>";
        if(($category!=null) && ($search!=null)){
        if($category != 'all'){ 
            $sql = "SELECT * FROM Property WHERE PropertyType = '$category' AND SaleType ='$cat' AND City ='$search' AND Price<=$budget ";
            $result = $conn->query($sql);        
            if ($result->num_rows > 0){
                
            while($row1 = $result->fetch_assoc()){
            $id=$row1["PropertyID"];
           // $pid[]=$id;
            
            $sql2="SELECT * FROM images WHERE PropertyID = $id  ORDER BY id DESC";
            $result2 = $conn->query($sql2);
            //while($row2 = $result2->fetch_assoc()){
                $row2 = $result2->fetch_assoc();
                $id1=$row2["images_url"];

                echo "<div><table class='container'>";
                // echo "<tr class='login-container1'> ";
                echo "<tr><td>"?> <div class="alb">
                <img id="img" src="upload-image/uploads/<?=$id1?>" style="width:100% ; height:100%">
                </div> <?php "</td></tr>";
                echo "<tr><td> <label> Name : </label>".$row1["RepresentativeName"]."<a href='http://localhost/upload-image/view.php'>view</a></td></tr>";
                echo "<tr><td> <label> Email : </label>".$row1["Email"]."</td></tr>";
                echo "<tr><td> <label> Representative type : </label>".$row1["RepresentativeType"]."</td></tr>";
                echo "<tr><td> <label>  Location : </label>".$row1["PropertyAddress"]."</td></tr>";
       // echo "</tr>";
                 echo "</table></div>";
          //  }      
            } 
        }
            else {
                alert( "No records found!");
            }

        }
        else{
            
             /* $sql = "SELECT * FROM Property WHERE SaleType ='$stype' and City ='$search'";//prints all properties of that area
              $result = $conn->query($sql);
              echo "2";
              $sql2="SELECT * FROM images WHERE PropertyID = $id  ORDER BY id DESC";
              $result2 = $conn->query($sql2);*/

              $sql = "SELECT * FROM Property WHERE SaleType ='$cat' and City ='$search'";//prints all properties of that area
              $result = $conn->query($sql);    
              if ($result->num_rows > 0){
                
              while($row1 = $result->fetch_assoc()){
            
              $id=$row1["PropertyID"];
             // $pid[]=$id;
             $sql2="SELECT * FROM images WHERE PropertyID = $id  ORDER BY id DESC";
              $result2 = $conn->query($sql2);
              //while($row2 = $result2->fetch_assoc()){
                $row2 = $result2->fetch_assoc();
                  $id1=$row2["images_url"];
  
                  echo "<div><table class='container'>";
                // echo "<tr class='login-container1'> ";
                echo "<tr><td>"?> <div class="alb">
                <img id="img" src="upload-image/uploads/<?=$id1?>" style="width:100% ; height:100%">
                </div> <?php "</td></tr>";
                echo "<tr><td> <label> Name : </label>".$row1["RepresentativeName"]."<a href='http://localhost/upload-image/view.php'>view</a></td></tr>";
                echo "<tr><td> <label> Email : </label>".$row1["Email"]."</td></tr>";
                echo "<tr><td> <label> Representative type : </label>".$row1["RepresentativeType"]."</td></tr>";
                echo "<tr><td><label>  Location : </label>".$row1["PropertyAddress"]."</td></tr>";
       // echo "</tr>";
                 echo "</table></div>";
            //  }       
              
        } 
    }
        else {
            echo "No records found!";
        }

          
          
                }
       // if ($result->num_rows > 0 && $result2->num_rows > 0) {




           
      //  
    }
    else{
          echo"Please enter values!";
        }
         
    }
   // echo"<div id='z'></div>";
   
    // Close connection
    $conn->close();
    ?>
    </div>
    <div id="z"> lol</div>
    <footer>
            <div class="icon-links">
                <!-- Social media icons -->
                <a href="#" title="Facebook"><i class="fab fa-facebook"></i></a>
                <a href="#" title="Twitter"><i class="fab fa-twitter"></i></a>
                <a href="#" title="Instagram"><i class="fab fa-instagram"></i></a>
                <!-- Add more social media icons as needed -->
        
                <!-- Contact information -->
                <p>Contact us: RealEstateSolutions@example.com | Phone: +123456789</p>
                <p>&copy; 2024 Real Estate Solutions. All Rights Reserved.</p>
            </div>
        </footer>
  
    

</body>
</html>
