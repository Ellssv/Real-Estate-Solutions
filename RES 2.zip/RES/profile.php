<?php
session_start();

if(isset($_SESSION['ID'])){
 //  echo $_SESSION['last_id'];
include "db_conn.php";
}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Details</title>
    <link  rel="stylesheet" href="home1.css">
</head>
<body>
<header id="h1">
      <label for="logo">REAL ESTATE SOLUTION</label>
    </header>
    <header id="h2">
      <nav>
        <ul>
          <li><a href="http://localhost/home1.html">HOME</a></li>
          <li><a href="http://localhost/aboutus.html">ABOUT</a></li>
          <li><a href="http://localhost/buy.php">BUY</a></li>
          <li><a href="http://localhost/rent.php">RENT</a></li>
          <li><a href="http://localhost/Propertyupload.html">SELL</a></li>
          <li><a href="http://localhost/home1.html">PROPERTY SERVICES</a></li>
          <li class="dropdown">
            
            <a href="" class="dropbtn">ACCOUNT</a>
            <div class="dropdown-content">
              <a href="http://localhost/profile.php">view profile </a>
              <a href="http://localhost/Logout.php">Logout</a>
            </div></li>
            
            <li class="dropdown">
              <a href="" class="dropbtn">HELP</a>
            <div class="dropdown-content">
              <a href="http://localhost/Login.html">#phone </a>
              <a href="http://localhost/Signin.html">#email</a>
            </div></li>
         
         
        </ul>
      </nav>
    </header>
    <div class="login-container">
    <h2>Account Details</h2>
    <?php
    
    $conn = new mysqli("localhost", "root", "", "RealEstate");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $id=$_SESSION['ID'];
    
    $sql = "SELECT * FROM Users WHERE  id=$id";
    $result = $conn->query($sql);
    
    if (mysqli_num_rows($result) > 0) {
        
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<p>Name: " . $row["FirstName"] ." ".$row["LastName"]."</p>";
            echo "<p>Email: " . $row["Email"] . "</p>";
            echo "<p>Contact: " . $row["Number"] . "</p>";
           
        }
    } else {
        echo "No account found.";
    }

    // Close connection
    mysqli_close($conn);
    ?>
    </div>

</body>
</html>
