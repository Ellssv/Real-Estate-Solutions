<?php
session_start();

if(isset($_SESSION['ID'])){
 
 $Name=$_POST['name'];
 $pno=intval($_POST['pno']);
 $email=$_POST['email'];
 $Rtype=$_POST['Rtype'];
 $ptype=$_POST['ptype'];
 $city=null;
 $PINcode=0;
 $SCname=null;
 $FPno=0;
 $PA=null;
 $PC=null;
 $PS=null;
 $SType=null;
 $Asf=0;
 $Rpsf=0;
 $price=0;
 $id=$_SESSION['ID'];

 echo $id;
 //message = "Welcome, " . $_SESSION['FirstName']." ".$_SESSION['ID'];
 //echo "<script>alert('$message');</script>";

 
 $conn = new mysqli('localhost','root','','RealEstate');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {


		/*$sql = "SELECT ID FROM Users where Email='$email'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                //echo $row["Email"];
                $email1=$row["Email"];
                $pwd=$row["Password"];
                $name=$row["FirstName"];
				//$id=$row["ID"];
			}}*/


		$stmt = $conn->prepare("insert into Property( RepresentativeName, Contact, Email, RepresentativeType, PropertyType, City, PINcode,SCName, FPno, PropertyAddress, PropertyConfiguration, PropertyStatus, SaleType, AreaSqFt, RatePrSqFt, Price, userID) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"); 
		$stmt->bind_param("sissssisissssiiii", $Name, $pno, $email, $Rtype, $ptype, $city, $PINcode, $SCname, $FPno, $PA,  $PC, $PS, $SType, $Asf, $Rpsf, $price, $id);
		$execval = $stmt->execute();
		//echo $execval;
		$_SESSION['last_id'] = $conn->insert_id;
		$stmt->close();
		$conn->close();
	}
	if($ptype=="Residential")
	{
		header("Location: Residential.html");
        exit; 
	}elseif($ptype=="Commercial")
	{
		header("Location: Commercial.html");
        exit; 
	}
 
}
?>