<?php
 $Fname=$_POST['Fname'];
 $Lname=$_POST['Lname'];
 $phone=$_POST['phone'];
 $email=$_POST['email'];
 $pwd1=$_POST['pwd1'];
 $pwd2=$_POST['pwd2']; 
 $gender=$_POST['gender'];

 $conn = new mysqli('localhost','root','','RealEstate');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$hashedPassword = password_hash($pwd2, PASSWORD_DEFAULT);
		$stmt = $conn->prepare("insert into Users(FirstName, LastName, Gender, Password, Number, Email,hashedpwd) values(?, ?, ?, ?, ?, ?, ?)"); 
		$stmt->bind_param("ssssiss", $Fname, $Lname, $gender, $pwd1, $phone,$email,$hashedPassword);
		$execval = $stmt->execute();
		echo $execval;
		//$hashedPassword = password_hash($pwd2, PASSWORD_DEFAULT);


		$sql = "SELECT ID,FirstName,Email,Password FROM Users where Email='$email'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                //echo $row["Email"];
                $email1=$row["Email"];
                //$pwd=$row["Password"];
                $name=$row["FirstName"];
                $id=$row["ID"];
			}
		}


		session_start();
		$_SESSION['FirstName'] = $Fname;
		$_SESSION['ID'] = $id;

		$message = "Welcome, " . $_SESSION['FirstName']." ".$_SESSION['ID'];
        echo "<script>alert('$message');</script>";

		$stmt->close();
		$conn->close();

		$link="home2.html";
        $redirect_delay=1;

		header("Refresh: $redirect_delay; URL=$link");
        exit;
	}
 
?>