
<!DOCTYPE html>
<?php
  $id=$_POST['t1'];
?>
<html>
<head>
    <title>Filter and Retrieve Data</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link  rel="stylesheet" href="search.css">
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
     
</head>




 <header id="h1">
     <label for="logo">REAL ESTATE SOLUTION</label>
 </header>
          <header id="h2">
            <nav>
              <ul>
                
                <li><a href="http://localhost/home2.html">HOME</a></li>
                <li><a href="http://localhost/aboutus.html">ABOUT</a></li>
                <li><a href="http://localhost/buy.php">BUY</a></li>
                <li><a href="http://localhost/rent.php">RENT</a></li>
                <li><a href="http://localhost/login.html">SALE</a></li>
                <li><a href="http://localhost/home1.html">PROPERTY SERVICES</a></li>
                <li class="dropdown">
                  
                  <a href="" class="dropbtn">ACCOUNT</a>
                  <div class="dropdown-content">
                    <a href="http://localhost/Login.html">Login </a>
                    <a href="http://localhost/Signin.html">Sign in</a>
                  </div></li>
                  
                  <li class="dropdown">
                    <a href="" class="dropbtn">HELP</a>
                  <div class="dropdown-content">
                    <a href="http://localhost/Login.html">#phone </a>
                    <a href="http://localhost/Signin.html">#email</a>
                  </div></li>
              </ul>
            </nav>
          </header>
          <div class="login-container">
        <div class="filter">
     <form  method="Post">
        <div class="form" >
            <input class="search" type="text" name="city" placeholder="Search City...">
        </div>
     
        <div class="form" >
          <label for="category">Property Type : </label>
           <select name="category" id="category">
              <option value="all">All Categories</option>
              <option value="Residential" >Residential</option>
              <option value="Commercial">Commercial</option>
              </select></div>
            <!--  -->
            <div class="form" >
            <label for="cat">Sale Type : </label>
             <select name="cat" id="cat">
              <option value="Sell">Buy </option>
              <option value="Rent" >Rent</option>
              
            <!--  -->
           </select></div><br><br>
           <div class="form">
            <label for="budget">Budget : </label>
            <input type="Number" name="budget" id="budget">
           </div>
           <div class="form">
        <input type="submit" class="button"  value="filter" name="submit"></div>
    </form></div>
</div>

<?php
$id=intval($_POST['t1']);

echo "<div class='con'>";


echo $id;


    $conn = new mysqli("localhost", "root", "", "RealEstate");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    else {
    if(!isset($_POST['submit'])) {
      //  $id=$_POST['id'];
    
    $sql = "SELECT * FROM Property WHERE PropertyID = $id  ";
    $result = $conn->query($sql);        
    if ($result->num_rows > 0){

     //   echo "<table class='login-container1'>";
   echo "<div id='left'><table class='container'>";
    while($row1 = $result->fetch_assoc()){
    $id=$row1["PropertyID"];


    echo "<tr><td> <label> Name : </label>".$row1["RepresentativeName"]."</td></tr>";
    echo "<tr><td> <label> Email : </label>".$row1["Email"]."</td></tr>";
    echo "<tr><td><label> Representative type : </label>".$row1["RepresentativeType"]."</td></tr>";
    echo "<tr><td> <label> Location : </label>".$row1["PropertyAddress"]."</td></tr>";
    echo "<tr><td><label> Sale type : </label>".$row1["SaleType"]."</td></tr>";
    echo "<tr><td><label> Price : </label>".$row1["Price"]."</td></tr>";
    echo "</table></div>";
    
    echo "<div id='right'><table class='container'>";
    $sql2="SELECT * FROM images WHERE PropertyID = $id  ORDER BY id DESC";
    $result2 = $conn->query($sql2);
    echo"<tr>";
    while($row2 = $result2->fetch_assoc()){
      //  $row2 = $result2->fetch_assoc();
        $id1=$row2["images_url"];
       // echo "<div><table class='container'>";
       // echo "<tr class='login-container1'> ";
        echo "<td>"?> <div class="alb">
        <img id="img" src="upload-image/uploads/<?=$id1?>" style="width:100% ; height:100%">
         </div> <?php "</td>";
        
       // echo "</tr>";
      //  echo "</table></div>";
       
   }
   echo "</tr>";      
    }
    echo "</table></div>";
    //
     echo "</table>";
} 
echo"</div>";
    }

else
if(isset($_POST['submit'])) {
    $category = $_POST['category'];
    $cat=$_POST['cat'];
    $search = $_POST['city'];
    $budget=$_POST['budget'];
   
    //echo "<table>";
    if(($category!=null) && ($search!=null)){
    if($category != 'all'){ 
        $sql = "SELECT * FROM Property WHERE PropertyType = '$category' AND SaleType ='$cat' AND City ='$search' AND Price<=$budget ";
        $result = $conn->query($sql);        
        if ($result->num_rows > 0){
            
        while($row1 = $result->fetch_assoc()){
        $id=$row1["PropertyID"];
       // $pid[]=$id;
        
        $sql2="SELECT * FROM images WHERE PropertyID = $id  ORDER BY id DESC";
        $result2 = $conn->query($sql2);
        //while($row2 = $result2->fetch_assoc()){
            $row2 = $result2->fetch_assoc();
            $id1=$row2["images_url"];

            echo "<div><table class='container'>";
            // echo "<tr class='login-container1'> ";
            echo "<tr><td>"?> <div class="alb">
            <img id="img" src="upload-image/uploads/<?=$id1?>" style="width:100% ; height:100%">
            </div> <?php "</td></tr>";
            echo "<tr><td> <label> Name : </label>".$row1["RepresentativeName"]."<a href='http://localhost/upload-image/view.php'>view</a></td></tr>";
            echo "<tr><td> <label> Email : </label>".$row1["Email"]."</td></tr>";
            echo "<tr><td> <label> Representative type : </label>".$row1["RepresentativeType"]."</td></tr>";
            echo "<tr><td> <label>  Location : </label>".$row1["PropertyAddress"]."</td></tr>";
   // echo "</tr>";
             echo "</table></div>";
      //  }      
        } 
    }
        else {
            alert( "No records found!");
        }

    }
    else{
        
         /* $sql = "SELECT * FROM Property WHERE SaleType ='$stype' and City ='$search'";//prints all properties of that area
          $result = $conn->query($sql);
          echo "2";
          $sql2="SELECT * FROM images WHERE PropertyID = $id  ORDER BY id DESC";
          $result2 = $conn->query($sql2);*/

          $sql = "SELECT * FROM Property WHERE SaleType ='$cat' and City ='$search'";//prints all properties of that area
          $result = $conn->query($sql);    
          if ($result->num_rows > 0){
            
          while($row1 = $result->fetch_assoc()){
        
          $id=$row1["PropertyID"];
         // $pid[]=$id;
         $sql2="SELECT * FROM images WHERE PropertyID = $id  ORDER BY id DESC";
          $result2 = $conn->query($sql2);
          //while($row2 = $result2->fetch_assoc()){
            $row2 = $result2->fetch_assoc();
              $id1=$row2["images_url"];

              echo "<div><table class='container'>";
            // echo "<tr class='login-container1'> ";
            echo "<tr><td>"?> <div class="alb">
            <img id="img" src="upload-image/uploads/<?=$id1?>" style="width:100% ; height:100%">
            </div> <?php "</td></tr>";
            echo "<tr><td> <label> Name : </label>".$row1["RepresentativeName"]."<a href='http://localhost/upload-image/view.php'>view</a></td></tr>";
            echo "<tr><td> <label> Email : </label>".$row1["Email"]."</td></tr>";
            echo "<tr><td> <label> Representative type : </label>".$row1["RepresentativeType"]."</td></tr>";
            echo "<tr><td><label>  Location : </label>".$row1["PropertyAddress"]."</td></tr>";
   // echo "</tr>";
             echo "</table></div>";
        //  }       
          
    } 
}
    else {
        echo "No records found!";
    }

      
      
            }
   // if ($result->num_rows > 0 && $result2->num_rows > 0) {




       
  //  
}
else{
      echo"Please enter values!";
    }
     
}
    }

// Close connection
$conn->close();
?>
</body>

</html>