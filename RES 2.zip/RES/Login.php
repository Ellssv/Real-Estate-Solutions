<?php
$username=$_POST['username'];
$password=$_POST['password'];
$flag=0;

$conn = new mysqli('localhost','root','','RealEstate');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$sql = "SELECT ID,FirstName,Email,Password FROM Users where Email='$username'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                //echo $row["Email"];
                $email1=$row["Email"];
                $pwd=$row["Password"];
                $name=$row["FirstName"];
                $id=$row["ID"];
                if(($username==$email1)&&($password==$pwd))
                {
                    $flag=1;
                    $message = "Login Sucessfull!";
                    echo "<script>alert('$message');</script>";
                    session_start();
                    $_SESSION['FirstName'] = $name;
                    $_SESSION['ID'] = $id;
                    header("Location: welcome.php");
            exit;
                }
                else {
                    $message = "Login Uncessfull, Wrong password!";
                    echo "<script>alert('$message');</script>";
                }
                
            }
        }
         else {

            $message = "Please sign in to Login!";
                    echo "<script>alert('$message');</script>";
            
        }
        
	}
    //if($flag==1)
   // {
     //   echo "Login Sucessfull!";
    //}
    //else echo "Login unsucessfull!";
?>